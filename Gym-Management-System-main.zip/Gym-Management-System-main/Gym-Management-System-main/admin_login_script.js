document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('loginForm');
  const errorMsg = document.getElementById('errorMsg');
  const emailInput = document.getElementById('email');
  const passwordInput = document.getElementById('password');

  // ✅ Example correct credentials
  const adminEmail = "admin@gmail.com";
  const adminPassword = "admin123";

  // Validation functions
  function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  function validatePassword(password) {
    return password.length >= 6; // Minimum 6 characters
  }

  function showError(message) {
    errorMsg.textContent = message;
    errorMsg.style.color = "red";
  }

  function clearError() {
    errorMsg.textContent = "";
  }

  // Real-time validation on input
  emailInput.addEventListener('input', () => {
    if (!validateEmail(emailInput.value.trim())) {
      showError("Please enter a valid email address.");
    } else {
      clearError();
    }
  });

  passwordInput.addEventListener('input', () => {
    if (!validatePassword(passwordInput.value.trim())) {
      showError("Password must be at least 6 characters long.");
    } else {
      clearError();
    }
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    clearError();

    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();

    let isValid = true;

    if (!validateEmail(email)) {
      showError("Please enter a valid email address.");
      isValid = false;
    } else if (!validatePassword(password)) {
      showError("Password must be at least 6 characters long.");
      isValid = false;
    }

    if (isValid) {
      if (email === adminEmail && password === adminPassword) {
        alert("✅ Login Successful!");
        // Replace this with your dashboard page path
        window.location.href = "admin_dashboard.html";
      } else {
        showError("❌ Invalid email or password!");
      }
    }
  });
});
