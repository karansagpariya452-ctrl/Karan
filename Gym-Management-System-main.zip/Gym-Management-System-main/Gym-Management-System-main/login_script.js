
let signup = document.querySelector(".signup");
let login = document.querySelector(".login");
let slider = document.querySelector(".slider");
let formSection = document.querySelector(".form-section");

// Form elements
let loginBtn = document.getElementById("login-btn");
let signupBtn = document.getElementById("signup-btn");

// Error elements
let loginEmailError = document.getElementById("login-email-error");
let loginPasswordError = document.getElementById("login-password-error");
let signupNameError = document.getElementById("signup-name-error");
let signupEmailError = document.getElementById("signup-email-error");
let signupPasswordError = document.getElementById("signup-password-error");
let signupConfirmError = document.getElementById("signup-confirm-error");

// Toggle between login and signup
signup.addEventListener("click", () => {
    slider.classList.add("moveslider");
    formSection.classList.add("form-section-move");
});

login.addEventListener("click", () => {
    slider.classList.remove("moveslider");
    formSection.classList.remove("form-section-move");
});

// Validation functions
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validatePassword(password) {
    return password.length >= 6;
}

function validateName(name) {
    return name.trim().length > 0;
}

// Clear errors
function clearErrors() {
    loginEmailError.textContent = "";
    loginPasswordError.textContent = "";
    signupNameError.textContent = "";
    signupEmailError.textContent = "";
    signupPasswordError.textContent = "";
    signupConfirmError.textContent = "";
}

// Login validation
loginBtn.addEventListener("click", (e) => {
    e.preventDefault();
    clearErrors();

    let email = document.querySelector(".login-box .email").value;
    let password = document.querySelector(".login-box .password").value;

    let isValid = true;

    if (!validateEmail(email)) {
        loginEmailError.textContent = "Please enter a valid email address.";
        isValid = false;
    }

    if (!validatePassword(password)) {
        loginPasswordError.textContent = "Password must be at least 6 characters long.";
        isValid = false;
    }

    if (isValid) {
        // Proceed with login (e.g., send to server)
        alert("Login successful!");
        // Here you would typically send the data to the server
    }
});

// Signup validation
signupBtn.addEventListener("click", (e) => {
    e.preventDefault();
    clearErrors();

    let name = document.querySelector(".signup-box .name").value;
    let email = document.querySelector(".signup-box .email").value;
    let password = document.querySelector(".signup-box .password").value;
    let confirmPassword = document.querySelector(".signup-box .confirm-password").value;

    let isValid = true;

    if (!validateName(name)) {
        signupNameError.textContent = "Name is required.";
        isValid = false;
    }

    if (!validateEmail(email)) {
        signupEmailError.textContent = "Please enter a valid email address.";
        isValid = false;
    }

    if (!validatePassword(password)) {
        signupPasswordError.textContent = "Password must be at least 6 characters long.";
        isValid = false;
    }

    if (password !== confirmPassword) {
        signupConfirmError.textContent = "Passwords do not match.";
        isValid = false;
    }

    if (isValid) {
        // Proceed with signup (e.g., send to server)
        alert("Signup successful!");
        // Here you would typically send the data to the server
    }
});
 