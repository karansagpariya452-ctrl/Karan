// Navigation switching
const links = document.querySelectorAll(".nav-link");
const sections = document.querySelectorAll(".page-section");

links.forEach(link => {
  link.addEventListener("click", () => {
    links.forEach(l => l.classList.remove("active"));
    link.classList.add("active");

    sections.forEach(sec => {
      sec.classList.remove("active");
      if (sec.id === link.getAttribute("href").substring(1)) {
        sec.classList.add("active");
      }
    });
  });
});

// Logout
document.getElementById("logoutBtn").addEventListener("click", () => {
  alert("Logged out successfully!");
  window.location.reload();
});

// Chart.js Report
const ctx = document.getElementById("reportChart");
if (ctx) {
  new Chart(ctx, {
    type: "bar",
    data: {
      labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
      datasets: [{
        label: "Monthly Revenue (₹)",
        data: [12000, 15000, 18000, 22000, 26000, 30000],
        backgroundColor: "#27ae60"
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } }
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  const membersTable = document.getElementById('membersTable').querySelector('tbody');
  const addBtn = document.getElementById('addMemberBtn');

  // Remove member
  membersTable.addEventListener('click', (e) => {
    if (e.target.classList.contains('removeBtn')) {
      if (confirm("Are you sure you want to remove this member?")) {
        e.target.closest('tr').remove();
      }
    }
  });

  // Add member (dummy example)
  addBtn.addEventListener('click', () => {
    const newRow = document.createElement('tr');
    newRow.innerHTML = `
      <td>New Member</td>
      <td>newmember@gmail.com</td>
      <td>Monthly</td>
      <td>2025-10-10</td>
      <td>2025-11-10</td>
      <td><span class="status active">Active</span></td>
      <td>
        <button class="editBtn">Edit</button>
        <button class="removeBtn">Remove</button>
      </td>
    `;
    membersTable.appendChild(newRow);
  });
});
