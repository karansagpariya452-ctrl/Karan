document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('loginForm');
  const errorMsg = document.getElementById('errorMsg');

  // ✅ Example correct credentials
  const adminEmail = "admin@gmail.com";
  const adminPassword = "admin123";

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();

    // Validation
    if (!email) {
      errorMsg.textContent = "❌ Email is required!";
      return;
    }
    if (!isValidEmail(email)) {
      errorMsg.textContent = "❌ Please enter a valid email address!";
      return;
    }
    if (!password) {
      errorMsg.textContent = "❌ Password is required!";
      return;
    }
    if (password.length < 6) {
      errorMsg.textContent = "❌ Password must be at least 6 characters long!";
      return;
    }

    if (email === adminEmail && password === adminPassword) {
      errorMsg.textContent = "";
      alert("✅ Login Successful!");
      // Replace this with your dashboard page path
      window.location.href = "admin_dashboard.html";
    } else {
      errorMsg.textContent = "❌ Invalid email or password!";
    }
  });

  // Helper function to validate email format
  function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }
});
